using namespace std;
class KTP 
{
	public :
		void full(string nk, string nm, string al, int us){
			nik = nk;
			nama = nm;
			alamat = al;
			usia = us;
		}
		
		string nik, nama, alamat;
		int usia;
};