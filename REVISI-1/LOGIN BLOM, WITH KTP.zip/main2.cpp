#include <iostream>
#include <fstream>
#include <string.h>
#include <sstream>
#include "data.h"
#include "array1d.h"
#include "kelas.h"
#include "tampilData.h"
#include "tampilKtp.h"
#include "xcept.h"
#include "login.h"
using namespace std;
int main()
{
    cout<<"Hello World";
    rentalKendaraan x;
    x.login();
}